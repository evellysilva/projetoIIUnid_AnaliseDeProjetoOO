package br.ifpe.edu.salao.apresentacao;

import java.util.ArrayList;
import java.util.List;

import br.ifpe.edu.salao.Servico;
import br.ifpe.edu.salao.negocio.AtualizarServico;
import br.ifpe.edu.salao.negocio.DAOFactory;
import br.ifpe.edu.salao.negocio.PacoteDebutante;
import br.ifpe.edu.salao.negocio.PacoteNoiva;
import br.ifpe.edu.salao.persistencia.GenericDAO;

public class SalaoFacade {
	private static SalaoFacade instancia;
    private GenericDAO<Servico> servicoDAO;

    private SalaoFacade() {
        // Inicializa o controlador usando a fábrica DAOFactory
        this.servicoDAO = DAOFactory.getInstance().criarDAO();
    }

    public static SalaoFacade getInstance() {
        if (instancia == null) {
            instancia = new SalaoFacade();
        }
        return instancia;
    }

    public void criarServico(int id, String nome, double preco, String descricao, int tipoPacote) {
    	Servico servico = new Servico(id, nome, preco, descricao);

        switch (tipoPacote) {
            case 1:
                servico = new PacoteNoiva(servico);
                break;
            case 2:
                servico = new PacoteDebutante(servico);
                break;
            default:
                break;  // Nenhum pacote adicional
        }

        servicoDAO.criar(servico);
    }

    public void atualizarServico(int id, String nome, double preco, String descricao) {
        AtualizarServico atualizarServico = new AtualizarServico(servicoDAO);
        atualizarServico.processarServico(id, nome, preco, descricao, 0); // TipoPacote não é necessário para atualização
    }

    public void removerServico(int id) {
        Servico servico = servicoDAO.buscar(id);
        if (servico != null) {
            servicoDAO.deletar(servico);
        } else {
            System.out.println("Serviço não encontrado.");
        }
    }

    public Servico buscarServico(int id) {
    	 Servico servico = servicoDAO.buscar(id);
         if (servico != null) {
             servico = aplicarPacoteDecorator(servico);
         }
         return servico;
     }
    public List<Servico> listarTodosServicos() {
    	 List<Servico> servicos = servicoDAO.listarTudo();
         List<Servico> servicosDecorados = new ArrayList<>();

         for (Servico servico : servicos) {
             servicosDecorados.add(aplicarPacoteDecorator(servico));
         }

         return servicosDecorados;
     }
    private Servico aplicarPacoteDecorator(Servico servico) {
        if (servico.getDescricao().contains("Pacote Noiva")) {
            return new PacoteNoiva(servico);
        } else if (servico.getDescricao().contains("Pacote Debutante")) {
            return new PacoteDebutante(servico);
        } else {
            return servico;
        }
    }
}    