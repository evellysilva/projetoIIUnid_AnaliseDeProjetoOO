package br.ifpe.edu.salao.apresentacao;

import br.ifpe.edu.salao.Servico;

import java.util.List;
import java.util.Scanner;

public class Aplicacao {

	public static void iniciar() {
        SalaoFacade facade = SalaoFacade.getInstance();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("Escolha uma opção:");
            System.out.println("1. Criar Serviço");
            System.out.println("2. Atualizar Serviço");
            System.out.println("3. Remover Serviço");
            System.out.println("4. Buscar Serviço por ID");
            System.out.println("5. Listar Todos os Serviços");
            System.out.println("6. Sair");
            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    criarServico(scanner, facade);
                    break;
                case 2:
                    atualizarServico(scanner, facade);
                    break;
                case 3:
                    removerServico(scanner, facade);
                    break;
                case 4:
                    buscarServico(scanner, facade);
                    break;
                case 5:
                    listarTodosServicos(facade);
                    break;
                case 6:
                    running = false;
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }

        scanner.close();
    }
    private static void criarServico(Scanner scanner, SalaoFacade facade) {
        try {
            System.out.println("Digite o código de identificação do serviço:");
            int id = scanner.nextInt();
            scanner.nextLine();

            System.out.println("Digite o nome do serviço:");
            String nome = scanner.nextLine();

            System.out.println("Informe a descrição do serviço:");
            String descricao = scanner.nextLine();

            System.out.println("Digite o preço do serviço:");
            double preco = scanner.nextDouble();
            scanner.nextLine();

            System.out.println("Escolha o tipo de pacote:");
            System.out.println("1 para Pacote de Noiva");
            System.out.println("2 para Pacote de Debutante");
            System.out.println("3 para Nenhum (serviço básico)");

            int tipoPacote = scanner.nextInt();
            scanner.nextLine();

            facade.criarServico(id, nome, preco, descricao, tipoPacote);
            System.out.println("Serviço criado com sucesso!");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro ao criar serviço: " + e.getMessage());
        }
    }

    private static void atualizarServico(Scanner scanner, SalaoFacade facade) {
        System.out.println("Digite o código de identificação do serviço que deseja atualizar:");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Digite o novo nome do serviço:");
        String nome = scanner.nextLine();

        System.out.println("Digite a nova descrição do serviço:");
        String descricao = scanner.nextLine();

        System.out.println("Digite o novo preço do serviço:");
        double preco = scanner.nextDouble();
        scanner.nextLine();

        facade.atualizarServico(id, nome, preco, descricao);
        System.out.println("Serviço atualizado com sucesso!");
    }

    private static void removerServico(Scanner scanner, SalaoFacade facade) {
        System.out.println("Digite o ID do serviço que deseja remover:");
        int id = scanner.nextInt();
        scanner.nextLine();

        facade.removerServico(id);
        System.out.println("Serviço removido com sucesso!");
    }

    private static void buscarServico(Scanner scanner, SalaoFacade facade) {
        System.out.println("Digite o código de identificação do serviço que deseja buscar:");
        int id = scanner.nextInt();
        scanner.nextLine();

        Servico servico = facade.buscarServico(id);
        if (servico != null) {
            System.out.println("Serviço encontrado:");
            System.out.println(servico);
        } else {
            System.out.println("Serviço não encontrado.");
        }
    }

    private static void listarTodosServicos(SalaoFacade facade) {
        List<Servico> servicos = facade.listarTodosServicos();
        if (servicos.isEmpty()) {
            System.out.println("Nenhum serviço encontrado.");
        } else {
            System.out.println("Lista de serviços:");
            for (Servico servico : servicos) {
                System.out.println(servico);
                System.out.println("------------------------");
            }
        }
    }

}