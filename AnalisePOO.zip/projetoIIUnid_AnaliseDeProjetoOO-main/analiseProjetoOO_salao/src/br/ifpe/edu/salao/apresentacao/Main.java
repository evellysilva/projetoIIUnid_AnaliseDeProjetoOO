package br.ifpe.edu.salao.apresentacao;

public class Main {
    public static void main(String[] args) {
        Aplicacao.iniciar();
    }
}
